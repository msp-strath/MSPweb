
int identical (double x, double y);
